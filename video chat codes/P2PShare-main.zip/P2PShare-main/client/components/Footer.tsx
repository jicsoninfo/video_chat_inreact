import React from 'react'
import Typography from '@mui/material/Typography'

const Footer: React.FC = (props) => {
  return (
    <div className="flex items-center justify-center font-sans text-sm text-white">
      {/* <div className="tetx-sm text-center">
        <Typography variant="body2">Made with ❤️ by</Typography>
        <Typography variant="caption">
          <a
            className="text-sky-500"
            href="https://github.com/piyushgarg-dev"
            target="_blank"
          >
            Piyush Garg
          </a>{' '}
          <span>and</span>{' '}
          <a
            className="text-sky-500"
            href="https://github.com/ashmitmittal"
            target="_blank"
          >
            Ashmit Mittal
          </a>
        </Typography> 
  </div> */}
    </div>
  )
}

export default Footer
